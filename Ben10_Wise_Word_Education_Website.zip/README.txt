# Ben10 Wise Word of Our Time — Education Website

This is a responsive starter website for an educational platform.

## Files
- index.html — website structure/content
- style.css — design and responsive layout
- script.js — mobile menu, year, and contact-form demo

## How to use
Open `index.html` in a browser.

## Before publishing
Replace the sample contact form behavior with a real form service/backend, add your real phone/email/social links, and add your own lessons, photos, logo, and downloadable resources.

Suggested tagline:
"Knowledge, Wisdom and Education for Our Time."
