function toggleMenu(){
  const nav=document.getElementById('navLinks');
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
}
document.querySelectorAll('#navLinks a').forEach(a=>{
  a.addEventListener('click',()=>{ if(window.innerWidth<=800) document.getElementById('navLinks').style.display='none'; });
});
document.getElementById('year').textContent=new Date().getFullYear();

function sendMessage(e){
  e.preventDefault();
  const name=document.getElementById('name').value.trim();
  document.getElementById('formMessage').textContent =
    `Thank you, ${name}! Your message has been received. Connect a form service or backend to receive submissions by email.`;
  e.target.reset();
}
